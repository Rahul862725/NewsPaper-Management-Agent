package paperMaster;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import jdbcc.ConnectToDatabase;
import javafx.scene.control.Label;

public class viewpaperMasterController {
	 
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> combo;

    @FXML
    private TextField txt;
    @FXML
    private Label lbl;

    @FXML
    void donew(ActionEvent event) {
    	lbl.setText("");
    	txt.setText("");
    	combo.getSelectionModel().select(0);
    }
    @FXML
    void dofetch(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("select * from papers where paper=?");
			pstmt.setString(1,combo.getEditor().getText());
			ResultSet tableref=pstmt.executeQuery();
			boolean flag=false;
			while(tableref.next())
			{
				flag=true;
				String n=tableref.getString("price");
				txt.setText(n);				
			}
			if(flag==false)
				lbl.setText("paper name does not exist");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    @FXML
    void doremove(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("delete from papers where paper=?");
			pstmt.setString(1, combo.getEditor().getText());
			
			int count=pstmt.executeUpdate();
			if(count==0)
				lbl.setText("Such newspapers does not exist");
			else
				lbl.setText(count+" newspapers deleted successfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void dosave(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("insert into papers values(?,?)");
			pstmt.setString(1, combo.getEditor().getText());
			pstmt.setFloat(2,Float.parseFloat(txt.getText()));
			
			pstmt.executeUpdate();
			lbl.setText("Newspaper added to the list !!!");
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			lbl.setText("check if all fields are filled ans try again");
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			lbl.setText("duplicate entry !!! Click on update...");
		}
    }

    @FXML
    void doupdate(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("update papers set price=? where paper=?");
			pstmt.setString(2, combo.getEditor().getText());
			pstmt.setFloat(1,Float.parseFloat(txt.getText()));
			
			int count=pstmt.executeUpdate();
			if(count==0)
				lbl.setText("Such newspapers does not exist");
			else
				lbl.setText(count+" newspapers updated with price");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    Connection con;
    PreparedStatement pstmt;
    @FXML
    void initialize() {
      con=ConnectToDatabase.getConnection();
      ArrayList<String>lst=new ArrayList<String>();
      lst.add("select/addnew");
      try {
		pstmt=con.prepareStatement("select * from papers");
		ResultSet tableref=pstmt.executeQuery();
		while(tableref.next())
			lst.add(tableref.getString("paper"));
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
//      ArrayList<String>lst=new ArrayList<String>(Arrays.asList("select/type","Wall Street Journal","Times of India (TOI)","Hindustan Times (HT)","Indian Express","English Tribune","Hindi Tribune","Punjabi Tribune"));
  		combo.getItems().addAll(lst);
  		combo.getSelectionModel().select(0);
    }
}
