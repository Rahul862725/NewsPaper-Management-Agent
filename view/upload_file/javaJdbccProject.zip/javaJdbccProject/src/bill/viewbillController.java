package bill;
import javafx.scene.input.MouseEvent;
import jdbcc.ConnectToDatabase;
import sms.SST_SMS;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;

public class viewbillController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> combo;

    @FXML
    private Label lbl;

    @FXML
    private ListView<String> lstpaper;

    @FXML
    private TextField txtdays;

    @FXML
    private ListView<String> lstprice;

    @FXML
    private TextField txtbill;

    @FXML
    void dofill(ActionEvent event) {
    	try {
    		lstpaper.getItems().clear();
    		lstprice.getItems().clear();
			pstmt=con.prepareStatement("select * from customers where mobile=?");
			pstmt.setString(1,combo.getEditor().getText());
			ResultSet tableref=pstmt.executeQuery();
			boolean flag=false;
			
			while(tableref.next())
			{
//				ld=tableref.getDate("doj");
				java.sql.Date dobb=tableref.getDate("curdate");
				LocalDate ldob=dobb.toLocalDate();
//				dob.setValue(ldob);
				ld=ldob;
				flag=true;
				String arlist=tableref.getString("papers");
				String arr[]=arlist.split(",");
				for(String s:arr) {
					lstpaper.getItems().addAll(s);
				}
				lbl.setText("");
			}
			if(flag==false)
				lbl.setText("Customer is not registered");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
//    	lstpaper.getSelectionModel().select(0);
    	lstpaper.getSelectionModel().selectAll();
    	
    	ArrayList<String>lst=new ArrayList<String>();
        try {
  		pstmt=con.prepareStatement("select distinct price from papers where paper=?");
  		ObservableList<String> selectedItems=lstpaper.getSelectionModel().getSelectedItems();
    	for(String items:selectedItems)
    	{
    		pstmt.setString(1,items);
//    		System.out.println(items+"  ");
    		ResultSet tableref=pstmt.executeQuery();
      		while(tableref.next()) {
//      			System.out.println(tableref.getString("price")+"  ");
      			lst.add(tableref.getString("price"));
      		}
      		
    	}
    	lstprice.getItems().addAll(lst);
  	} catch (SQLException e) {
  		
  		e.printStackTrace();
  	}
    }
    LocalDate ld;
    @FXML
    void dobill(ActionEvent event) {
    	float bill=0;
    	ObservableList<String> obj=lstprice.getItems();
    	for(String s:obj)
    		bill+=Float.parseFloat(s);
    	Duration diff=Duration.between(ld.atStartOfDay(),LocalDate.now().atStartOfDay());
        long noofdays=diff.toDays();
        if(noofdays<=0) 
        {
        	 txtbill.setText(String.valueOf(0));
             txtdays.setText(String.valueOf(0));
        }
        else {
        bill=bill*noofdays;
        
        txtbill.setText(String.valueOf(bill));
        txtdays.setText(String.valueOf(noofdays));}
        
        try {
			pstmt=con.prepareStatement("update customers set curdate=DATE_ADD(CURRENT_DATE,INTERVAL 1 DAY) where mobile=?");
			pstmt.setString(1, combo.getEditor().getText());
			int c=pstmt.executeUpdate();
			if(c==0)
				lbl.setText("Customer name does not exist");
			else
				lbl.setText(c+" customer's last generated bill date updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    

    @FXML
    void dosave(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("insert into billing(custmobile,days,bill) values(?,?,?)");
			pstmt.setString(1, combo.getEditor().getText());
			pstmt.setString(2, txtdays.getText());
			pstmt.setString(3, txtbill.getText());
			pstmt.executeUpdate();
			sendSMS(combo.getEditor().getText(),"Registered Successfully");
			lbl.setText("Bill saved and message sent !!!");
		} 
    	catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			lbl.setText("check if all fields are filled ans try again");
			e.printStackTrace();
		}
    	catch (SQLException e) {
			// TODO Auto-generated catch block
			lbl.setText("check if all fields are filled ans try again");
			e.printStackTrace();
		}
    }
    void sendSMS(String mobile,String msg)
    {
    	String resp=SST_SMS.bceSunSoftSend(mobile, msg);
    	
    	if(resp.indexOf("Exception")!=-1)
    	lbl.setText("Check Internet Connection for SMS");
    	
    	else
    		if(resp.indexOf("successfully")!=-1)
    			lbl.setText("Bill saved and message sent !!!");
    		else
    			lbl.setText( "Invalid Number");
    }
    Connection con;
    PreparedStatement pstmt;
    @FXML
    void initialize() {
    	con=ConnectToDatabase.getConnection();
        ArrayList<String>lst=new ArrayList<String>();
        lst.add("select/addnew");
        try {
  		pstmt=con.prepareStatement("select * from customers");
  		ResultSet tableref=pstmt.executeQuery();
  		while(tableref.next())
  			lst.add(tableref.getString("mobile"));
  	} catch (SQLException e) {
  		
  		e.printStackTrace();
  	}
//        ArrayList<String>lst=new ArrayList<String>(Arrays.asList("select/type","ram","sham","rahul","raman","aman","shaman","ramu"));
    		combo.getItems().addAll(lst);
    		combo.getSelectionModel().select(0);
    		lstpaper.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }
}
