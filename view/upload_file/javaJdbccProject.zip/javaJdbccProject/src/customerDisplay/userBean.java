package customerDisplay;

public class userBean {
	String mobile,name,address,papers,area,hawker,curdate;
	userBean(){
		
	}
	public userBean(String mobile, String name, String address, String papers, String area, String hawker,
			String curdate) {
		super();
		this.mobile = mobile;
		this.name = name;
		this.address = address;
		this.papers = papers;
		this.area = area;
		this.hawker = hawker;
		this.curdate = curdate;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPapers() {
		return papers;
	}
	public void setPapers(String papers) {
		this.papers = papers;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getHawker() {
		return hawker;
	}
	public void setHawker(String hawker) {
		this.hawker = hawker;
	}
	public String getCurdate() {
		return curdate;
	}
	public void setCurdate(String curdate) {
		this.curdate = curdate;
	}
	
}
