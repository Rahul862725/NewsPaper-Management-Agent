package customerDisplay;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import jdbcc.ConnectToDatabase;

public class viewcustomerDisplayController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> combo;

    @FXML
    private ComboBox<String> combo1;

    @FXML
    private TableView<userBean> table;

    @FXML
    void dofetch(ActionEvent event) {
    	int index=combo.getSelectionModel().getSelectedIndex();
    	ObservableList<userBean> ary=getAllRecords();
    	ObservableList<userBean> ary2=getAllRecords2();
    	
    	TableColumn<userBean,String> mobile=new TableColumn<userBean,String>("Mobile no.");
    	mobile.setCellValueFactory(new PropertyValueFactory<>("mobile"));
    	mobile.setMinWidth(100);
    	
    	TableColumn<userBean,String> name=new TableColumn<userBean,String>("Name");
    	name.setCellValueFactory(new PropertyValueFactory<>("name"));
    	name.setMinWidth(100);
    	TableColumn<userBean,String> address=new TableColumn<userBean,String>("Address");
    	address.setCellValueFactory(new PropertyValueFactory<>("address"));
    	address.setMinWidth(100);
    	TableColumn<userBean,String> papers=new TableColumn<userBean,String>("Papers");
    	papers.setCellValueFactory(new PropertyValueFactory<>("papers"));
    	papers.setMinWidth(100);
    	TableColumn<userBean,String> area=new TableColumn<userBean,String>("Area");
    	area.setCellValueFactory(new PropertyValueFactory<>("area"));
    	area.setMinWidth(100);
    	TableColumn<userBean,String> hawker=new TableColumn<userBean,String>("Hawker");
    	hawker.setCellValueFactory(new PropertyValueFactory<>("hawker"));
    	hawker.setMinWidth(100);
    	TableColumn<userBean,String> curdate=new TableColumn<userBean,String>("Curdate");
    	curdate.setCellValueFactory(new PropertyValueFactory<>("curdate"));
    	curdate.setMinWidth(100);
    	
    	
    	table.getColumns().addAll(mobile,name,address,papers,area,hawker,curdate);
    	table.setItems(null);
    	
    	
    	if(index==0)
    	table.setItems(ary2);
    	else
    		table.setItems(ary);
    }
//    String name=comboarea.getSelectionModel().getSelectedItem();
//	try {
//		pstmt=con.prepareStatement("select name from hawkers where areas like ?");
//		pstmt.setString(1,"%"+ name+"%");
//		ResultSet hawker=pstmt.executeQuery();
//		while(hawker.next())
//		{
//			String hn=hawker.getString("name");
//			txthawker.setText(hn);
//		}
//	} catch (SQLException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
    ObservableList<userBean> getAllRecords2(){
    	ObservableList<userBean> ary2=FXCollections.observableArrayList();
    	return ary2;
    }
    ObservableList<userBean> getAllRecords() {
    	ObservableList<userBean> ary=FXCollections.observableArrayList();
    	try {
			pstmt=con.prepareStatement("select * from customers where area=?");
			pstmt.setString(1, combo.getEditor().getText());
			ResultSet tableref=pstmt.executeQuery();
			while(tableref.next()) {
				String mobile=tableref.getString("mobile");
				String name=tableref.getString("name");
				String address=tableref.getString("address");
				String papers=tableref.getString("papers");
				String area=tableref.getString("area");
				String hawker=tableref.getString("hawker");
				String curdate=tableref.getString("curdate");
				userBean ref=new userBean(mobile,name,address,papers,area,hawker,curdate);
				ary.add(ref);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return ary;
    }
    
    Connection con;
    PreparedStatement pstmt;
    @FXML
    void initialize() {
    	con=ConnectToDatabase.getConnection();
    	ResultSet areas;
        try {
  		pstmt=con.prepareStatement("select distinct area from customers");
  		areas=pstmt.executeQuery();
  		combo.getItems().add("select");
  		while(areas.next()) {
  			String a[]=areas.getString("area").split(",");
  			ArrayList<String> ax=new ArrayList<String>(Arrays.asList(a));
  			for(String x:ax)
  				combo.getItems().addAll(x);
  	} 
        }catch (SQLException e) {
  		
  		e.printStackTrace();
  	}
    combo.getSelectionModel().select(0);
    
    ResultSet pp;
    try {
		pstmt=con.prepareStatement("select distinct paper from papers");
		pp=pstmt.executeQuery();
		combo1.getItems().add("select");
		while(pp.next()) {
			String a[]=pp.getString("paper").split(",");
			ArrayList<String> ax=new ArrayList<String>(Arrays.asList(a));
			for(String x:ax)
				combo1.getItems().addAll(x);
	} 
    }catch (SQLException e) {
		
		e.printStackTrace();
	}
combo1.getSelectionModel().select(0);

    }
}
