package customer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.scene.input.MouseEvent;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import jdbcc.ConnectToDatabase;

public class viewcustomerController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> combo;

    @FXML
    private TextField txtname;

    @FXML
    private Label lbl;

    @FXML
    private TextField txtadd;

    @FXML
    private ListView<String> lstpaper;

    @FXML
    private TextField txthawker;
    
    @FXML
    private ComboBox<String> comboarea;

    @FXML
    void dofetch(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("select * from customers where mobile=?");
			pstmt.setString(1,combo.getEditor().getText());
			ResultSet tableref=pstmt.executeQuery();
			boolean flag=false;
			while(tableref.next())
			{
				flag=true;
				txtname.setText(tableref.getString("name"));
				txtadd.setText(tableref.getString("address"));
				txthawker.setText(tableref.getString("hawker"));
				comboarea.getSelectionModel().select(tableref.getString("area"));
				String arlist=tableref.getString("papers");
				String arr[]=arlist.split(",");
				for(String s:arr)
					lstpaper.getSelectionModel().select(s);
			}
			if(flag==false)
				lbl.setText("Customer is not registered");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void donew(ActionEvent event) {
    	lbl.setText("");
    	txthawker.setText("");
    	txtadd.setText("");
    	txtname.setText("");
    	lstpaper.getSelectionModel().select(0);
    	combo.getSelectionModel().select(0);
    }

    @FXML
    void doremove(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("delete from customers where mobile=?");
			pstmt.setString(1, combo.getEditor().getText());
			
			int count=pstmt.executeUpdate();
			if(count==0)
				lbl.setText("Customer is not registered");
			else
				lbl.setText(count+" Customer removed successfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @FXML
    void gethawker(MouseEvent event) {
    	String name=comboarea.getSelectionModel().getSelectedItem();
    	try {
			pstmt=con.prepareStatement("select name from hawkers where areas like ?");
			pstmt.setString(1,"%"+ name+"%");
			ResultSet hawker=pstmt.executeQuery();
			while(hawker.next())
			{
				String hn=hawker.getString("name");
				txthawker.setText(hn);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
   
    @FXML
    void dosave(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("insert into customers(mobile,name,address,papers,area,hawker) values(?,?,?,?,?,?)");
			pstmt.setString(1, combo.getEditor().getText());
			pstmt.setString(2, txtname.getText());
			pstmt.setString(3, txtadd.getText());
			
			String papersstr="";
	    	ObservableList<String> selectedItems=lstpaper.getSelectionModel().getSelectedItems();
	    	
	    	for(String items:selectedItems) {
	    		papersstr+=items+",";
	    	}
			pstmt.setString(4, papersstr);
			pstmt.setString(6, txthawker.getText());			
			pstmt.setString(5, comboarea.getEditor().getText());
		pstmt.executeUpdate();
			lbl.setText("Hawker added to the list !!!");
		} 
    	catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			lbl.setText("check if all fields are filled ans try again");
			e.printStackTrace();
		}
    	catch (SQLException e) {
			// TODO Auto-generated catch block
			lbl.setText("check if all fields are filled ans try again");
			e.printStackTrace();
		}
    }

    @FXML
    void doupdate(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("update customers set name=?,address=?,papers=?,area=?,hawker=? where mobile=?");
			pstmt.setString(6, combo.getEditor().getText());
			pstmt.setString(5, comboarea.getEditor().getText());
			pstmt.setString(4,txthawker.getText());
			pstmt.setString(1, txtname.getText());
			pstmt.setString(2, txtadd.getText());
			
			String p="";
	    	ObservableList<String> selectedItems=lstpaper.getSelectionModel().getSelectedItems();
	    	for(String items:selectedItems)
	    		p+=items+",";
			pstmt.setString(3, p);
			
			int count=pstmt.executeUpdate();
			if(count==0)
				lbl.setText("Customer name does not exist");
			else
				lbl.setText(count+" customer's details updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    Connection con;
    PreparedStatement pstmt;
    @FXML
    void initialize() {
    	con=ConnectToDatabase.getConnection();
        ArrayList<String>lst=new ArrayList<String>();
        lst.add("select/addnew");
        try {
  		pstmt=con.prepareStatement("select * from customers");
  		ResultSet tableref=pstmt.executeQuery();
  		while(tableref.next())
  			lst.add(tableref.getString("mobile"));
  	} catch (SQLException e) {
  		
  		e.printStackTrace();
  	}
//        ArrayList<String>lst=new ArrayList<String>(Arrays.asList("select/type","ram","sham","rahul","raman","aman","shaman","ramu"));
    		combo.getItems().addAll(lst);
    		combo.getSelectionModel().select(0);
    		
    		ArrayList<String>lst2=new ArrayList<String>();
    	      
    	      try {
    			pstmt=con.prepareStatement("select * from papers");
    			ResultSet tableref2=pstmt.executeQuery();
    			while(tableref2.next())
    				lst2.add(tableref2.getString("paper"));
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
//    	      ArrayList<String>lst=new ArrayList<String>(Arrays.asList("select/type","Wall Street Journal","Times of India (TOI)","Hindustan Times (HT)","Indian Express","English Tribune","Hindi Tribune","Punjabi Tribune"));
    	  		lstpaper.getItems().addAll(lst2);
    		lstpaper.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    		
    		  ResultSet areas;
		        try {
		  		pstmt=con.prepareStatement("select distinct areas from hawkers");
		  		areas=pstmt.executeQuery();
		  		comboarea.getItems().add("select");
		  		while(areas.next()) {
		  			String a[]=areas.getString("areas").split(",");
		  			ArrayList<String> ax=new ArrayList<String>(Arrays.asList(a));
		  			for(String x:ax)
		  				comboarea.getItems().addAll(x);
		  	} 
		        }catch (SQLException e) {
		  		
		  		e.printStackTrace();
		  	}
		    comboarea.getSelectionModel().select(0);
    		
    	
    }
}
