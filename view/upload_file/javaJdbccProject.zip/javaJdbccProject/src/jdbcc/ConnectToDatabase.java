package jdbcc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectToDatabase {
	public static Connection getConnection() {
		Connection con=null;
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost/javaJdbccProject","root","Shivani@11");
//			System.out.println("connected");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
//	public static void main(String args[]) {
//		Connection conRef=getConnection();
//		if(conRef==null) System.out.println("****-ERROR-****");
//		else
//			System.out.println("****-CONECTED-****");
//	}
}
