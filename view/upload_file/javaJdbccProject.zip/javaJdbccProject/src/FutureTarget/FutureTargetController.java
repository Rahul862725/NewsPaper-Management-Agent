package FutureTarget;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.*;
import java.io.*;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
//import java.util.function.ToDoubleFunction;

//import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
//import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import jdbcc.ConnectToDatabase;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.FileChooser.ExtensionFilter;


public class FutureTargetController {
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField FInalResult;

    @FXML
    private Button FileUpload;

    @FXML
    private ComboBox<String> comboarea;

    @FXML
    private Label lbl;

    @FXML
    private Text tpp;

    @FXML
    private Text tr;

    @FXML
    private Label total;

//    @FXML
//    private Text tr;

    @FXML
    private TextField value;


    @FXML
    private Label tnp;
    static String filename="";
    @FXML

        boolean check1(Vector<String>list)
        {
            int c=0;
            for(int i=0;i<list.size();i++)
            {
                list.set(i,list.get(i).toUpperCase());
            }
            for(int i=0;i<list.size();i++)
            {
                if(list.get(i).equals("NO_OF_PAPER"))
                    c+=1;
                else if(list.get(i).equals("PRICE"))
                    c+=1;
            }

            if(c>=2)
                return true;
            else
                return false;
        }
    boolean check2(Vector<String>list)
    {
        int c=0;
        for(int i=0;i<list.size();i++)
        {
            list.set(i,list.get(i).toUpperCase());
        }
        for(int i=0;i<list.size();i++)
        {
            if(list.get(i).equals("LOCATION"))
                c+=1;
            else if(list.get(i).equals("PRICE"))
                c+=1;
        }
        if(c>=2)
            return true;
        else
            return false;
    }
        double sumList(Vector<Double>list)
        {
            double m=0;
            for(int i=0;i<list.size();i++)
            {
                m+=list.get(i);
            }
            return m;
        }

     Vector<Vector<String>> readFile(String csvFile) {
        Vector<Vector<String>>matr=new Vector<Vector<String>>();
//         System.out.println(csvFile);
        try {

            File file = new File(String.valueOf(csvFile));
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";

            String []tempArr;
            while((line = br.readLine()) != null) {
                tempArr = line.split(",");
                Vector<String>temp=new Vector<String>();

                for(String tempStr : tempArr) {
                    temp.add(tempStr);
//                    System.out.println(tempStr);
                }
                 matr.add(temp);
            }
            br.close();
        } catch(IOException ioe) {
            ioe.printStackTrace();
        }
        return matr;
   }
   Vector<Double>LinearRegression(Vector<Vector<Double>>matr)
   {
       Vector<Double>ans=new Vector<Double>();
       Vector<Double>temp1=new Vector<Double>();
       Vector<Double>temp2=new Vector<Double>();
       for(int i=0;i<matr.size();i++)
       {
             temp1.add(matr.get(i).get(0));
             temp2.add(matr.get(i).get(1));
       }
       int n=temp1.size();
       double x=sumList(temp1);
       double y=sumList(temp2);
       double xy=0;
       double x2=0;
       for(int i=0;i<temp1.size();i++)
       {
           x2+=temp1.get(i)*temp1.get(i);
           xy+=temp1.get(i)*temp2.get(i);
       }
       double m=(n*xy-x*y)/(n*x2-(x*x));
       double c=y/n-(m*x/n);
       ans.add(m);
       ans.add(c);

      return ans;
   }
//   void CurrentUpdate()   //Call this when any update done in front end tables
//   {
//       Vector<Double>lst2=new Vector<Double>(); // no of paper and bill
//       try {
//           pstmt=con.prepareStatement("select sum(days) from biling");
//           ResultSet tableref2=pstmt.executeQuery();
//           while(tableref2.next())
//               lst2.add(tableref2.getDouble("days"));
//       } catch (SQLException e) {
//           // TODO Auto-generated catch block
//           e.printStackTrace();
//       }
//       try {
//           pstmt=con.prepareStatement("select sum(bill) from biling");
//           ResultSet tableref2=pstmt.executeQuery();
//           while(tableref2.next())
//               lst2.add(tableref2.getDouble("bill"));
//       } catch (SQLException e) {
//           // TODO Auto-generated catch block
//           e.printStackTrace();
//       }
//
//       //Update No_Of_Paper and bill Continuausly
//   }

    @FXML
    void analysis()
    {


        Vector<Vector<String>>matr=readFile(filename);

        String svalue=comboarea.getValue();
//        System.out.println(svalue);
        //Select Option Code and Store in svalue


        if(svalue.equals("Find Revenue")) {
            if (matr.size()!=0&&!check1(matr.get(0))) {
                lbl.setText("excel csv file attribute not compatible");
            } else {
                Vector<Vector<Double>> matr1 = new Vector<Vector<Double>>();
                for (int i = 1; i < matr.size(); i++) {
                    Vector<Double> temp = new Vector<Double>();
                    double temp1 = 0, temp2 = 0;
                    for (int j = 0; j < matr.get(i).size(); j++) {
                        if (matr.get(0).get(j).toUpperCase().equals("NO_OF_PAPER"))
                            temp1 = Double.parseDouble(matr.get(i).get(j));
                        else if (matr.get(0).get(j).toUpperCase().equals("PRICE"))
                            temp2 = Double.parseDouble(matr.get(i).get(j));


                    }
                    temp.add(temp1);
                    temp.add(temp2);
                    matr1.add(temp);
                }

                Vector<Double> res1 = LinearRegression(matr1);

                String noOfPapers = value.getText();
                double va = Double.parseDouble(noOfPapers);
                double temp = res1.get(0);
                double va1=res1.get(1);
                double eValue = (temp * va);
                eValue+=va1;
//                System.out.println("Value is: "+eValue+"  "+va+" "+temp*va+va1);
                FInalResult.setText(String.valueOf(eValue));

            }
        }
        else if(svalue.equals("Find No Of Papers" )) {
            if (!check1(matr.get(0))) {
                // EXCEL FILE HAS NOT THESE FIELD PLEASE CHECK ALERT
                lbl.setText("excel csv file attribute not compatible");
            } else {
                Vector<Vector<Double>> matr1 = new Vector<Vector<Double>>();
                for (int i = 1; i < matr.size(); i++) {
                    Vector<Double> temp = new Vector<Double>();
                    double temp1 = 0, temp2 = 0;
                    for (int j = 0; j < matr.get(i).size(); j++) {
                        if (matr.get(0).get(j).toUpperCase().equals("NO_OF_PAPER"))
                            temp1 = Double.parseDouble(matr.get(i).get(j));
                        else if (matr.get(0).get(j).toUpperCase().equals("PRICE"))
                            temp2 = Double.parseDouble(matr.get(i).get(j));


                    }

                    temp.add(temp2);
                    temp.add(temp1);
                    matr1.add(temp);
                }
                Vector<Double> res1 = LinearRegression(matr1);
                String noOfPapers = value.getText();
                double va = Double.parseDouble(noOfPapers);
                double temp = res1.get(0);
                double eValue = (temp) * va + res1.get(1);

                FInalResult.setText(String.valueOf(eValue));
            }
        }
        else if(svalue.equals("Find Best Location")) {
            if (!check2(matr.get(0))) {
                // EXCEL FILE HAS NOT THESE FIELD PLEASE CHECK
                lbl.setText("excel csv file attribute not compatible");
            } else {
                Vector<Vector<String>> matr3 = new Vector<Vector<String>>();
                for (int i = 1; i < matr.size(); i++) {
                    Vector<String> temp = new Vector<String>();
                    String temp1 = "", temp2 = "";
                    for (int j = 0; j < matr.get(i).size(); j++) {
                        if (matr.get(0).get(j).toUpperCase().equals("LOCATION"))
                            temp1 = (matr.get(i).get(j));
                        else if (matr.get(0).get(j).toUpperCase().equals("PRICE"))
                            temp2 = (matr.get(i).get(j));


                    }

                    temp.add(temp1);
                    temp.add(temp2);
                    matr3.add(temp);
                }

                Map<String, Double> temp = new HashMap<String, Double>();
                String location = "";
                double ma = 0;
                for (int i = 0; i < matr3.size(); i++) {
                    if (!temp.containsKey(matr3.get(i).get(0)))
                        temp.put(matr3.get(i).get(0), Double.parseDouble(matr3.get(i).get(1)));
                    else
                        temp.put(matr3.get(i).get(0), temp.get(matr3.get(i).get(0)) + Double.parseDouble(matr3.get(i).get(1)));
                    if (ma < temp.get(matr3.get(i).get(0))) {
                        ma = temp.get(matr3.get(i).get(0));
                        location = matr3.get(i).get(0);
                    }
                }

                FInalResult.setText(location);

            }
        }
        else if(svalue.equals("Select"))
        {
            lbl.setText("Choosen list not applicable");
        }
        else {
            //"Please Fill all the Field Alert"
            lbl.setText("Please Fill all the Field");
        }
    }

        @FXML
        void dofx(ActionEvent event) {
            JFileChooser fileChooser = new JFileChooser();
//			int response = fileChooser.showOpenDialog(null); //select file to open
            int response = fileChooser.showSaveDialog(null); //select file to save

            if(response == JFileChooser.APPROVE_OPTION) {
                File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
                filename=file.getPath();

            }
            //Take File in csv format
//            JFileChooser fc=new JFileChooser();
//            fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
//             FileNameExtensionFilter excelFile=new FileNameExtensionFilter("CSV Files","csv");
//             fc.addChoosableFileFilter(excelFile);
//             fc.setFileFilter(excelFile);
//             exfile=fc.getSelectedFile();
////             filename=exfile.getName();
//             System.out.println("Name is: "+exfile);
//
//
////            fc.getExtensionFilters().add(new ExtensionFilter("CSV Files","*.csv"));
////            exfile=fc.showOpenDialog(null);
////            filename =fc.
//
////            System.out.println("Filname is: "+filename);
////            File f=fc.showSaveDialog(own);
////             File excelfile;
////            try {
////               excelfile =new File(new FileInputStream());
////            }
////            catch(FileNotFoundException e){
////                e.printStackTrace();
////            }
            if(filename!=null)
            {
                lbl.setText("Not File Choosen");
            }

//            String area=comboarea.getEditor().getText();   // SELECTED AREA ARRAY
//            String noOfPapers=txt.getText();    // NO. OF PAPERS
//            lbl.setText("papers="+papersstr+" \narea="+area+" no. of papers="+noOfPapers);
        }


        @FXML
        void gethawker(MouseEvent event) {

        }
        Connection con;
        PreparedStatement pstmt;
        ArrayList<String>excellst;
        @FXML
        void initialize() {

            con=ConnectToDatabase.getConnection();
           ArrayList<String> ar =new ArrayList<String>(Arrays.asList("Select","Find Revenue","Find No Of Papers","Find Best Location"));

           comboarea.getItems().addAll(ar);
           comboarea.getSelectionModel().select(0);

            comboarea.getSelectionModel().select(0);
            excellst=new ArrayList<String>(Arrays.asList("*.csv"));

            Vector<Double>lst3=new Vector<Double>(); // no of paper and bill
            try {
                pstmt=con.prepareStatement("select SUM(days) from billing");
                System.out.println("value"+pstmt);
                ResultSet tableref2=pstmt.executeQuery();
                while(tableref2.next()) {
                    lst3.add(tableref2.getDouble("SUM(days)"));
                    System.out.println("value");
                }
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            try {
                pstmt=con.prepareStatement("select SUM(bill) from billing");
                ResultSet tableref2=pstmt.executeQuery();
                while(tableref2.next())
                    lst3.add(tableref2.getDouble("SUM(bill)"));
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            tnp.setText(String.valueOf(lst3.get(0)));
            total.setText(String.valueOf(lst3.get(1)));

        }
    }


