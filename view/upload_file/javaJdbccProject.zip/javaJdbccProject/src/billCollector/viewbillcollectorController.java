package billCollector;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import jdbcc.ConnectToDatabase;

public class viewbillcollectorController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> combo;

    @FXML
    private Label lbl;

    @FXML
    private ListView<String> lstdate;

    @FXML
    private ListView<String> lstbill;

    @FXML
    private TextField txtbill;

    @FXML
    void dofill(ActionEvent event) {
    	try {
    		lstbill.getItems().clear();
    		lstdate.getItems().clear();
			pstmt=con.prepareStatement("select * from billing where custmobile=?");
			pstmt.setString(1,combo.getEditor().getText());
			ResultSet tableref=pstmt.executeQuery();
			boolean flag=false;
			ArrayList<String>lst=new ArrayList<String>();
			ArrayList<String>lst2=new ArrayList<String>();
			while(tableref.next())
			{
				java.sql.Date dobb=tableref.getDate("datebill");
				LocalDate ldob=dobb.toLocalDate();
				lst.add(String.valueOf(ldob));
				
				flag=true;
				
				lst2.add(String.valueOf(tableref.getFloat("bill")));
				
				lbl.setText("");
				
			}
			lstdate.getItems().addAll(lst);
			lstbill.getItems().addAll(lst2);
			if(flag==false)
				lbl.setText("Customer is not registered");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	float total=0;
    	ObservableList<String> obj=lstbill.getItems();
    	for(String s:obj)
    		total+=Float.parseFloat(s);
    	txtbill.setText(String.valueOf(total));
    }

    @FXML
    void dopaid(ActionEvent event) {
    	try {
    		pstmt=con.prepareStatement("update billing set status=1 where status=0 and custmobile=?");
			pstmt.setString(1, combo.getEditor().getText());
			pstmt.executeUpdate();
			lbl.setText("Bill paid by the customer and marked done");
		} 
    	
    	catch (SQLException e) {
			// TODO Auto-generated catch block
			lbl.setText("Customer details wrong");
			e.printStackTrace();
		}
    }
    Connection con;
    PreparedStatement pstmt;
    @FXML
    void initialize() {
    	con=ConnectToDatabase.getConnection();
        ArrayList<String>lst=new ArrayList<String>();
        lst.add("select/addnew");
        try {
  		pstmt=con.prepareStatement("select * from customers");
  		ResultSet tableref=pstmt.executeQuery();
  		while(tableref.next())
  			lst.add(tableref.getString("mobile"));
  	} catch (SQLException e) {
  		
  		e.printStackTrace();
  	}
//        ArrayList<String>lst=new ArrayList<String>(Arrays.asList("select/type","ram","sham","rahul","raman","aman","shaman","ramu"));
    		combo.getItems().addAll(lst);
    		combo.getSelectionModel().select(0);
    		lstdate.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }
}
