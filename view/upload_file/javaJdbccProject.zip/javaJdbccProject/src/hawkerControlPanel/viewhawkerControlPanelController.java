package hawkerControlPanel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import jdbcc.ConnectToDatabase;

public class viewhawkerControlPanelController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> combo;

    @FXML
    private TextField txtmob;

    @FXML
    private Label lbl;

    @FXML
    private TextField txtadd;

    @FXML
    private TextField txtsal;

    @FXML
    private ListView<String> lstarea;

    @FXML
    private ImageView img;
    
    @FXML
    private Label lbldoj;
    
    File image;
    @FXML
    void dochoose(ActionEvent event) {
    	FileChooser fc=new FileChooser();
    	fc.getExtensionFilters().add(new ExtensionFilter("Images", lstpic));
    	image=fc.showOpenDialog(null);
    	Image pic=null;
    	try {
    		pic=new Image(new FileInputStream(image));
    	}
    	catch(FileNotFoundException e){
    		e.printStackTrace();
    	}
    	if(image!=null)
    	{
    		img.setImage(pic);
    	}
    }

    @FXML
    void donew(ActionEvent event) {
    	lbl.setText("");
    	txtsal.setText("");
    	txtadd.setText("");
    	txtmob.setText("");
    	lstarea.getSelectionModel().select(0);
    	combo.getSelectionModel().select(0);
    	img.setImage(null);
    }

    @FXML
    void doremove(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("delete from hawkers where name=?");
			pstmt.setString(1, combo.getEditor().getText());
			
			int count=pstmt.executeUpdate();
			if(count==0)
				lbl.setText("Hawker name does not exist");
			else
				lbl.setText(count+" Hawker removed successfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void dosave(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("insert into hawkers(name,mobile,address,areas,pic,salary) values(?,?,?,?,?,?)");
			pstmt.setString(1, combo.getEditor().getText());
			pstmt.setString(2, txtmob.getText());
			pstmt.setString(3, txtadd.getText());
			
			String areas="";
	    	ObservableList<String> selectedItems=lstarea.getSelectionModel().getSelectedItems();
	    	for(String items:selectedItems)
	    		areas+=items+",";
			pstmt.setString(4, areas);
			
			if(image!=null)
				pstmt.setString(5, image.getAbsolutePath());
			else
				lbl.setText("Please select your pic");
			
			pstmt.setFloat(6,Float.parseFloat(txtsal.getText()));
			
			
		pstmt.executeUpdate();
			lbl.setText("Hawker added to the list !!!");
		} 
    	catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			lbl.setText("check if all fields are filled ans try again");
			e.printStackTrace();
		}
    	catch (SQLException e) {
			// TODO Auto-generated catch block
			lbl.setText("check if all fields are filled ans try again");
			e.printStackTrace();
		}
    }

    @FXML
    void dofetch(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("select * from hawkers where name=?");
			pstmt.setString(1,combo.getEditor().getText());
			ResultSet tableref=pstmt.executeQuery();
			boolean flag=false;
			while(tableref.next())
			{
				flag=true;
				txtmob.setText(tableref.getString("mobile"));
				txtadd.setText(tableref.getString("address"));
				txtsal.setText(String.valueOf(tableref.getFloat("salary")));
				
//				java.sql.Date dobb=tableref.getDate("doj");
//				LocalDate ldob=dobb.toLocalDate();
//				lbldoj.setText("hawker joined on: "+String.valueOf(ldob));
				
				image=new File(tableref.getString("pic"));
				try {
					img.setImage(new Image(new FileInputStream(image)));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String arlist=tableref.getString("areas");
				String arr[]=arlist.split(",");
				for(String s:arr)
					lstarea.getSelectionModel().select(s);
			}
			if(flag==false)
				lbl.setText("Hawker does not exist");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void doupdate(ActionEvent event) {
    	try {
			pstmt=con.prepareStatement("update hawkers set mobile=?,address=?,areas=?,salary=? where name=?");
			pstmt.setString(5, combo.getEditor().getText());
			pstmt.setFloat(4,Float.parseFloat(txtsal.getText()));
			pstmt.setString(1, txtmob.getText());
			pstmt.setString(2, txtadd.getText());
			
			String areas="";
	    	ObservableList<String> selectedItems=lstarea.getSelectionModel().getSelectedItems();
	    	for(String items:selectedItems)
	    		areas+=items+",";
			pstmt.setString(3, areas);
			
			int count=pstmt.executeUpdate();
			if(count==0)
				lbl.setText("Hawker's name does not exist");
			else
				lbl.setText(count+" hawker details updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    ArrayList<String> lstpic;
    Connection con;
    PreparedStatement pstmt;
    @FXML
    void initialize() {
      con=ConnectToDatabase.getConnection();
      ArrayList<String>lst=new ArrayList<String>();
      lst.add("select/addnew");
      try {
		pstmt=con.prepareStatement("select * from hawkers");
		ResultSet tableref=pstmt.executeQuery();
		while(tableref.next())
			lst.add(tableref.getString("name"));
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
//      ArrayList<String>lst=new ArrayList<String>(Arrays.asList("select/type","ram","sham","rahul","raman","aman","shaman","ramu"));
  		combo.getItems().addAll(lst);
  		combo.getSelectionModel().select(0);
  		
  		ArrayList<String> ar=new ArrayList<String>(Arrays.asList("select","model town","green city","ganpati enclave","chandni nagar","bibi wala road","dhobiana road"));
  		lstarea.getItems().addAll(ar);
  		lstarea.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
  		
  		lstpic=new ArrayList<String>(Arrays.asList("*.jpg","*.jpeg","*.png","*.pdf"));
    }
}
