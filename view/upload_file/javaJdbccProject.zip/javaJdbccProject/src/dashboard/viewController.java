package dashboard;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class viewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label lbl;

    @FXML
    void HawkerManger(MouseEvent event) {
    	try {
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("hawkerControlPanel/viewhawkerControlPanel.fxml"));
			Scene scene=new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void billrecord(MouseEvent event) {
    	try {
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("billCollector/viewbillCollector.fxml"));
			Scene scene=new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @FXML
    void billgenrator(MouseEvent event) {
    	try {
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("bill/viewbill.fxml"));
			Scene scene=new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @FXML
    void customermanager(MouseEvent event) {
    	try {
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("customer/viewcustomer.fxml"));
			Scene scene=new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void lblclick(MouseEvent event) {
//   	Desktop.getDesktop().mail();
    }

    @FXML
    void papermaster(MouseEvent event) {
    	try {
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("paperMaster/viewpaperMaster.fxml"));
			Scene scene=new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void viewall(MouseEvent event) {
    	try {
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("customerDisplay/viewcustomerDisplay.fxml"));
			Scene scene=new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	@FXML
	void FutureT(MouseEvent event) {
		try {
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("FutureTarget/FutureTa.fxml"));
			Scene scene=new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    @FXML
    void initialize() {
        assert lbl != null : "fx:id=\"lbl\" was not injected: check your FXML file 'view.fxml'.";

    }
}
